<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Qiniu\Auth;
use Qiniu\Sms\Sms;
use Illuminate\Support\Facades\Redis;

class qiniuController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $_accessKey = '';
    private $_secretKey = '';
    const VERIFY_CODE = 'verify:code:';
    public function __construct()
    {
        //
        $this->_accessKey = env('accessKey');
        $this->_secretKey = env('secretKey');
    }

    //
    public function send(Request $request)
    {
        $uuid = $request->input('uuid');
        $tel = $request->input('tel');

        if (empty($tel) || empty($uuid)) {
            return response()->json($this->response(400, '请填写手机号再发送'));
        }

        // echo $this->_accessKey, $this->_secretKey;
        if (Redis::get(self::VERIFY_CODE . $uuid)) {
            return response()->json($this->response(302, '60秒只能发送一次'));
        }
        $verify_code = mt_rand(111111, 999999);
        try {
            $auth = new Auth($this->_accessKey, $this->_secretKey);
            $sms = new Sms($auth);

            $ret = $sms->sendMessage('1163696936914526208', [$tel], ['code' => $verify_code]);

            $id = $ret[0]['job_id'];

            if (empty($id)) {
                return response()->json($this->response(500, '发送失败'));
            }
            Redis::setex(self::VERIFY_CODE . $uuid, 120, $tel . '_' . $verify_code);
            return response()->json($this->response(200, '发送成功'));
        } catch (\Exception $e) {
            return response()->json($this->response($e->getCode(), $e->getMessage()));
        }
    }

    public static function checkVerify($uuid, $tel, $verify_code)
    {
        $data = Redis::get(self::VERIFY_CODE . $uuid);
        if (empty($data)) {
            return false;
        }
        if ($data == $tel . '_' . $verify_code) {
            return true;
        }
        return false;
    }

    /**
     *
     * @param int $codeInt
     * @param string $msgStr
     * @param array $restultArr
     * @return array
     */
    private function response($code, $msg, $result = [])
    {
        return $result = array(
            'ret_code' => $code,
            'ret_msg' => $msg,
            'result' => $result,
        );
    }
}
